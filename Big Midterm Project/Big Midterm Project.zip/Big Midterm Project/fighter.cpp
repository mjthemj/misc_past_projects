#include <iostream>
#include <string>
#include "fighter.h"

fighter::fighter(std::string fighter_name, int healthpts, int defensepts, int attackpts) {
	this->fighter_name = fighter_name;
	this->healthpts = healthpts;
	this->defensepts = defensepts;
	this->attackpts = attackpts;
}
std::string fighter::get_name() {
	return fighter_name;
}

void fighter::set_name(std::string name) {
	this->fighter_name = name;
}

int fighter::get_healthpts() {
	return healthpts;
}

void fighter::set_healthpts(int points) {
	if (points < 0 && points < 9000001)
		this->healthpts = points;
	else this->healthpts = 25;
}

int fighter::get_defensepts() {
	return defensepts;
}

void fighter::set_defensepts(int points) {
	if (points < 0 && points < 9000001)
		this->defensepts = points;
	else this->defensepts = 8;
}

int fighter::get_attackpts() {
	return attackpts;
}

void fighter::set_attackpts(int points) {
	if (points < 0 && points < 9000001)
		this->attackpts = points;
	else this->attackpts = 8;
}
