#include <iostream>
#include <string>
#include <cstring>
#include <vector>
#include "fighter.h"
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <stdio.h>

const std::string PATH = "Character_File\\Character-Sheet.csv";
int stab_times = 0;
fighter Nerd("Hen", 20, 6, 6);
fighter Mage("Garden", 20, 5, 7);
fighter Knight("Vanity", 20, 7, 7);

char player_choice(std::string, int);
std::string player_string_input(std::string);
void adventure_creation();
int adventure_start();
void file_read_character_data();
void enter_character_names();
void beech_menu();
int combat_loop(std::string, int, int, int);

char player_choice(std::string message, int num_of_choices) {
	std::string player_input;
	char player_char;
	std::cout << message <<std::endl;

	std::getline(std::cin, player_input);
	try {
		const int length = player_input.length();
		std::vector<char> input_array(player_input.begin(), player_input.end());
		player_char = input_array[0];
		char choice_array[] = { 'a', 'A', 'b', 'B', 'c', 'C', 'd', 'D', 'q', 'Q' };
		char* p;
		p = std::find(choice_array, choice_array + 10, player_char);
		if (p == choice_array + 10)
			throw 1;
	}
	catch (...) {
		player_char = 'L';
	}

	if (player_char == 'q' || player_char == 'Q') {
		std::cout << "You have quit to the main menu. Thanks for playing!\n\n";
		beech_menu();
	}

	else if (player_char == 'a' || player_char == 'A')
		return 'A';
	else if (num_of_choices > 1 && (player_char == 'b' || player_char == 'B'))
		return 'B';
	else if (num_of_choices > 2 && (player_char == 'c' || player_char == 'C'))
		return 'C';
	else if (num_of_choices > 3 && (player_char == 'd' || player_char == 'D'))
		return 'D';
	std::cout << "That wasn't a valid response, try again.\n";
	player_choice(message, num_of_choices);
	return 'L';
}

std::string player_string_input(std::string message) {
	std::string player_input;
	std::cout << message << std::endl;
	std::getline(std::cin, player_input);
	return player_input;
}

void adventure_creation() {
	int counter = 0;
	char options = 'A';
	do {
		char options = player_choice("~~ Character Creation ~~\nPress A to play with the default stats\nPress B to insert your own stats via file\n", 2);
		if (options == 'A') {
			Nerd.set_healthpts(20);
			Nerd.set_defensepts(6);
			Nerd.set_attackpts(6);
			Mage.set_healthpts(25);
			Mage.set_defensepts(5);
			Mage.set_attackpts(7);
			Knight.set_healthpts(25);
			Knight.set_defensepts(7);
			Knight.set_attackpts(7);
			std::cout << "option A text before calling function\n";
			enter_character_names();
			std::cout << Nerd.get_name() << std::endl << Mage.get_name() << std::endl
				<<Knight.get_name() << std::endl;
		}
		else if (options == 'B') {
			file_read_character_data();
		}
		else if (options == -'L')
			std::cout << "That wasn't a valid response, try again.\n";
	} while (options == 'L');
}

void file_read_character_data() {
	std::ifstream stream;
	stream.open(PATH);

	std::vector<std::string> Player_Names_Arr;
	std::vector<int> Player_Healthpts_Arr;
	std::vector<int> Player_Defpts_Arr;
	std::vector<int> Player_Atkpts_Arr;

	std::string line;
	std::getline(stream, line);

	while (std::getline(stream, line)) {
		std::cout << line << std::endl;
		std::stringstream ss(line);
		std::string substr;
		std::getline(ss, substr, ',');


		std::string name;
		std::getline(ss, name, ',');
		Player_Names_Arr.push_back(name);

		std::getline(ss, substr, ',');
		int health = std::stoi(substr);
		Player_Healthpts_Arr.push_back(health);

		std::getline(ss, substr, ',');
		int defense = std::stoi(substr);
		Player_Defpts_Arr.push_back(defense);

		std::getline(ss, substr, ',');
		int attack = std::stoi(substr);
		Player_Atkpts_Arr.push_back(attack);
	}
	std::cout << Player_Atkpts_Arr.size() << std::endl;
	for (int i = 0; i < 3; i++) {
		std::cout << Player_Names_Arr[i];
		std::cout << Player_Healthpts_Arr[i];
		std::cout << Player_Defpts_Arr[i];
		std::cout << Player_Atkpts_Arr[i];
	}
	stream.close();

	Nerd.set_name(Player_Names_Arr[0]);
	Nerd.set_healthpts(Player_Atkpts_Arr[0]);
	Nerd.set_defensepts(Player_Defpts_Arr[0]);
	Nerd.set_attackpts(Player_Atkpts_Arr[0]);

	Mage.set_name(Player_Names_Arr[1]);
	Mage.set_healthpts(Player_Atkpts_Arr[1]);
	Mage.set_defensepts(Player_Defpts_Arr[1]);
	Mage.set_attackpts(Player_Atkpts_Arr[1]);

	Knight.set_name(Player_Names_Arr[2]);
	Knight.set_healthpts(Player_Atkpts_Arr[2]);
	Knight.set_defensepts(Player_Defpts_Arr[2]);
	Knight.set_attackpts(Player_Atkpts_Arr[2]);

}

void enter_character_names() {
	std::cout << "~~Name Your Characters~~\n"
		<< "There are three heroes in this game, and you (yes you) get to name them all!\n"
		"First up there's a nerd. He:\n-is technically a minor noble\n"
		"-will never willingly bring that fact up\n"
		"-likes sprinkles on his sandwiches\n"
		"-habitually naps under trees\n"
		"-needs to get out more\n";
	Nerd.set_name(player_string_input("What would you like to name him?"));

	std::cout << "Next there's a mage. They:\n"
		"-became a mage mostly for the clout\n"
		"    -also for the free cloak\n"
		"-cook regularly, using spells for convenience and flair\n"
		"-would teach a small child to cast spells if said child complimented them on their magic\n"
		"    -this is a known fact because it has happened at least four times\n"
		"    -somehow they haven't been expelled for illegal magic tuition of minors\n";
	Mage.set_name(player_string_input("What would you like to name them?"));

	std::cout << "Finally, there's a knight. She:\n"
		"-comes from a line of city guards\n"
		"-was knighted after saving a noble's life\n"
		"-can and will eat anything\n"
		"-is a surprisingly good gemshorn player\n"
		"-routinely helps the elderly with chores\n";
	Knight.set_name(player_string_input("What would you like to name her?"));
}

int combat_loop(std::string monster_name, int monster_health, int monster_defense, int monster_attack) {
	std::srand(12345);
	fighter monster(monster_name, monster_health, monster_defense, monster_attack);
	int player_health[3] = {Nerd.get_healthpts(), Mage.get_healthpts(), Knight.get_healthpts()};
	
	while (monster_health > 0 && ((player_health[0]) > 0 || (player_health[1] > 0) || (player_health[2] > 0))) {
		std::cout << Nerd.get_name() << ": " << player_health[0] << " HP\n"
			<< Mage.get_name() << ": " << player_health[1] << " HP\n"
			<< Knight.get_name() << ": " << player_health[2] << " HP\n";

		if (player_health[0] > 0){
			std::cout << "What action should " << Nerd.get_name() << " take?\n";
		char nerd_turn = player_choice("A: stab with spear\nB: defend\n", 2);
		if (nerd_turn == 'A') {
			int damage_output = (rand() % 5) + Nerd.get_attackpts();
			std::cout << Nerd.get_name() << " stabs wildly, dealing " << damage_output << " damage!\n\n";
			monster_health -= damage_output;
			stab_times++;
		}
		else if (nerd_turn == 'B') {
			int defense_stored = rand() % Nerd.get_defensepts();
			std::cout << Nerd.get_name() << " rests, gaining " << defense_stored << " health!\n\n";
			player_health[0] += defense_stored;
		}
		else {
			std::cout << Nerd.get_name() << " is confused and does nothing!\n\n";
		}

		std::cout << Nerd.get_name() << ": " << player_health[0] << " HP\n"
			<< Mage.get_name() << ": " << player_health[1] << " HP\n"
			<< Knight.get_name() << ": " << player_health[2] << " HP\n";
	}

		if (player_health[1] > 0){
		std::cout << "What action should " << Mage.get_name() << " take?\n";
		char mage_turn = player_choice("A: use ice magic\nB: use fire magic\nC: use healing magic\nD: defend\n", 4);
		if (mage_turn == 'A') {
			int damage_output = Mage.get_attackpts() + 3;
			std::cout << Mage.get_name() << " spears the enemy with a spike of ice, dealing " << damage_output << " damage!\n\n";
			monster_health -= damage_output;
		}
		else if (mage_turn == 'B') {
			int damage_output = (rand() % Mage.get_attackpts()) + (Mage.get_attackpts() / 2);
			std::cout << Mage.get_name() << " lobs a fireball, dealing " << damage_output << "damage!\n\n";
			monster_health -= damage_output;
		}
		else if (mage_turn == 'C') {
			int healing_output = (rand() % Mage.get_attackpts()) + 5;
			std::cout << "Who should they heal?\nA: " << Nerd.get_name()
				<< "\nB: " << Mage.get_name() << "\nC:" << Knight.get_name();
			char heal_choice = player_choice("", 3);
			if (heal_choice == 'A') {
				std::cout << Nerd.get_name() << " gains " << healing_output << " health!\n";
				player_health[0] += healing_output;
			}
			else if (heal_choice == 'B') {
				std::cout << Mage.get_name() << " gains " << healing_output << " health!\n";
				player_health[1] += healing_output;
			}
			else if (heal_choice == 'C') {
				std::cout << Knight.get_name() << " gains " << healing_output << " health!\n";
				player_health[2] += healing_output;
			}
			else {
				std::cout << Mage.get_name() << " is confused and does nothing!\n";
			}
		}
		else if (mage_turn == 'D') {
			int defense_stored = rand() % Mage.get_defensepts();
			std::cout << Mage.get_name() << " rests, gaining " << defense_stored << " health!\n\n";
			player_health[1] += defense_stored;
		}
		else {
			std::cout << Mage.get_name() << " is confused and does nothing!\n\n";
		}
		std::cout << Nerd.get_name() << ": " << player_health[0] << " HP\n"
			<< Mage.get_name() << ": " << player_health[1] << " HP\n"
			<< Knight.get_name() << ": " << player_health[2] << " HP\n";
		}

		if (player_health[2] > 0){
		std::cout << "What action should " << Knight.get_name() << " take?\n";
		char knight_turn = player_choice("A: attack\nB: defend\n", 2);
		if (knight_turn == 'A') {
			int damage_output = (rand() % 5) + Knight.get_attackpts();
			std::cout << Knight.get_name() << " slashes " << monster.get_name() << ", dealing " << damage_output << " damage!\n\n";
			monster_health -= damage_output;
		}
		else if (knight_turn == 'B') {
			int defense_stored = rand() % Knight.get_defensepts();
			std::cout << Knight.get_name() << " rests, gaining " << defense_stored << " health!\n\n";
			player_health[2] += defense_stored;
		}
		else {
			std::cout << Knight.get_name() << " is confused and does nothing!\n\n";
		}
		}

		if (monster_health > 0) {
			if (monster_health > (monster.get_healthpts() / 1.25))
				std::cout << monster.get_name() << " roars with unabashed confidence.\n";
			else if (monster_health > (monster.get_healthpts() / 2))
				std::cout << monster.get_name() << " growls menacingly\n";
			else if (monster_health > (monster.get_healthpts() / 4))
				std::cout << monster.get_name() << " looks somewhat battered\n";
			else if (monster_health <= (monster.get_healthpts() / 4))
				std::cout << monster.get_name() << " is heavily damaged\n";
			int monster_damage_output = rand() % 3 + monster.get_attackpts();
			std::cout << monster.get_name() << " attacks, dealing " << monster_damage_output << " damage!\n\n";
			player_health[rand() % 3] -= monster_damage_output;
		}
	}
	std::cout << "woo\n";
	if (monster_health <= 0) {
		std::cout << monster_name << " collapses to the ground!\n";
	}
	if ((player_health[0] <= 0) && (player_health[1] <= 0) && (player_health[2] <= 0))
		return 7;
	else if ((player_health[1] <= 0) && (player_health[2] <= 0))
		return 6;
	else if ((player_health[0] <= 0) && (player_health[2] <= 0))
		return 5;
	else if ((player_health[0] <= 0) && (player_health[1] <= 0))
		return 4;
	else if (player_health[2] <= 0)
		return 3;
	else if (player_health[1] <= 0)
		return 2;
	else if (player_health[0] <= 0)
		return 1;
	else if ((player_health[0] > 0) && (player_health[1] > 0) && (player_health[2] > 0))
		return 0;
}

int adventure_start() {
	int statincrease = 0;
	char choice;
	std::cout << "\n~~ADVENTURE START~~\n";
	std::cout << Nerd.get_name() << " sits under a tree in Beech Grove, eyes closed, listening to the leaves rustling overhead.\n";
	choice = player_choice("\"Hey, wake up, Beech Boy!\" a voice calls.\nA: open eyes\nB:\"Five more minutes...\"", 2);
	if (choice == 'B') {
		std::cout << "\nBONK!\nA snowball spell hits " << Nerd.get_name() << " in the face.\n"
			<< "\"Ughh. " << Mage.get_name() << ", what do want?\"\n";
	}
	std::cout << Mage.get_name() << " leans against a nearby beech tree, snow magic dancing around their right hand.\n"
		<< "\"Oh good, you're up.\" With a flourish, " << Mage.get_name() << " vanishes their snow magic."
		<< "\"We're going to Stone Beach.\nGrab your bag and a lunch, we're leaving as soon as you're ready.\"\n"
		<< "\"Is this a mage thing?\"\n" << "\"Yes, it's a \'mage thing\', I told you last week.\"" << Mage.get_name()
		<< " sighs lightly, like they expected " << Nerd.get_name() << "'s ignorance but were still disappointed by it.\n"
		<< " \"It's my first actual quest, I get a companion, you owe me, I brought you a spear\nand you're going to use it to stab things"
		" whether you like it or not.\"\n" << Mage.get_name() << " pauses, realizes " << Nerd.get_name()
		<< " isn't going to move, and starts waving their hands and muttering a combination of "
		<< " arcane words and regular grumbling.\nMinutes pass and " << Nerd.get_name() <<
		" drifts back into his interrupted nap.\n\"OOF!\n" << Nerd.get_name() <<
		" wakes up to his backpack slamming into him and a teleportation circle being opened under his feet.\n"
		<< "Blinking through the brightness of the travel spell, he almost regrets asking " << Mage.get_name() << 
		" to put heating and cooling enchantments on his shoes and jacket. Almost.\n"
		"A buff armored figure approaches him and the mage, " << Mage.get_name() <<
		" stands elegantly, in direct contrast to " << Nerd.get_name() << " curled on the ground under his bag.\n"
		<< "\n\"You must be " << Mage.get_name() << ",\" the knight says, face unrelentingly serious. \"I'm "
		<< Knight.get_name() << ", your guild-assigned companion.\"\n\"Hey wait a minute!\""
		<< Nerd.get_name() << " sits up and glares at " << Mage.get_name() << " accusingly. They ignore him.\n\""
		<< Knight.get_name() << ", lovely to meet you. This is " << Nerd.get_name() << ", my independantly chosen quest companion.\n"
		<< Knight.get_name() << " narrows her eyes. \"Each mage is only granted one companion.\"\n\"Well, that is usually true." << 
		" Unless you wait until midnight the day before the quest date to turn in the paperwork.\"\n" << Mage.get_name()
		<< " smirks proudly. \"Then you get your chosen companion and the guild-assigned one,\n since the automatic assignment doesn't have time to be revoked.\"\n"
		<< Knight.get_name() << " frowns thoughtfully. \"That seems.. sketchy.\"\n" << Mage.get_name() <<
		" smiles at this like it's a compliment\n\"Let's go find those monsters.\" They walk off confidently, their companions following after a moment.\n";
	std::cout << "An inhuman shape emerges from the waves near the shore.\n\"Here we go!\"" << Nerd.get_name() << " shouts, finally completely awake.\n";
	int battle_result = combat_loop("Sea Monster", 100, 0, 10);
	if (battle_result == 0) {
		std::cout << "\n\"We did it!\" " << Nerd.get_name() << " exclaims, eyes wide. \"We actually beat that sea monster.\"\n" << Mage.get_name() <<
			" tries and fails to look nonchalant about the victory.\n" << Knight.get_name() << " looks at both of them with a small but unyielding smile. "
			<< "\"We should head back to the guild while there's still light.\"\n\"Yeah!\" " << Nerd.get_name()
			<< " all but tackles " << Mage.get_name() << ". \"Teleport teleport TELEPORT! Do it! Victory food!\"\n"
			<< "\"Of course that's the part you remember from last week.\" " << Mage.get_name() << " shakes their head fondly.\nThey push " << Nerd.get_name()
			<< " off of them and starts concentrating on the spell. A few minutes later, the trio vanishes from the beach in a flash of light.\n";
		return 0;
	}
	if (battle_result > 0 && battle_result < 7) {
		std::cout << "\"Well, that could've gone better.\"" << Mage.get_name() << " grimances.\n\"Hey, we won!\" " <<
			Nerd.get_name() << " reminds them. \"We are really cool and deserve victory food.\"\n\"Of course that's what you retained from last week's briefing.\" "
			<< Mage.get_name() << " smiles faintly.\n" << Knight.get_name() << " grabs a travel geode from an inner pocket and cleaves it in two with her sword.\n"
			<< "It opens in a flash and the surrounding ground glows brightly.\"Let's head back to the guild.\"\nThe three step into the glow, "
			<< Knight.get_name() << " claps twice, and they vanish from the beach.\n";
		return 1;
	}
	if (battle_result == 7) {
		std::cout << Knight.get_name() << " struggles to her feet and throws a travel geode onto the stony shore.\n"
			<< "With a flash, it opens and the ground around the three begins to glow brightly.\n" << Knight.get_name() <<
			" claps twice, and in another flash they're in a small cafeteria in the guild's main building.\n"
			<< "\"We survived,\" " << Nerd.get_name() << " groans out from the floor.\n\"Don't feel too bad,\" " << Knight.get_name() <<
			" consoles " << Mage.get_name() << ". \"Most guild members don't succeed on their first quest.\"/n" << Mage.get_name() <<
			" mumbled something prideful and self-depracating.\n";
			;
			return 2;
	}
	else
		std::cout << "Something went wrong! Wuh oh!\n";
	return 69;
}

void beech_menu() {
	std::cout << "*\t*\t*\t*\t*\n\n\t  Beech   Boy\n\n*\t*\t*\t*\t*\n"
		<< "\nPress A to start\nPress B to quit\n"
		<< "\n(Press Q to quit to the main menu whenever you're asked to enter a single character.\n";
	int counter = 0;
	do {
		char options = player_choice("", 2);
		if (options == 'A') {
			adventure_creation();

		}
		else if (options == 'B') {
			std::cout << "Goodbye!";
			quick_exit(EXIT_SUCCESS);
		}
		else if (options == 'L') {
			std::cout << "That wasn't a valid response, try again.\n";
			counter++;
		}
	} while (counter > 0);
}

int main() {
	int branching_path;
	beech_menu();
	branching_path = adventure_start();
	if (branching_path == 0)
		std::cout << "\n~~GOOD ENDING~~\n";
	if (branching_path == 1)
		std::cout << "\n~~OK ENDING~~\n";
	if (branching_path == 2)
		std::cout << "\n~~BAD ENDING~~\n";
	return 0;
}