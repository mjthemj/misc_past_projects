#pragma once
#include <string>


class fighter {
private:
		std::string fighter_name;
		int healthpts;
		int defensepts;
		int attackpts;
public:
	fighter(std::string fighter_name, int healthpts, int defensepts, int attackpts);
	std::string get_name();
	void set_name(std::string);
	int get_healthpts();
	void set_healthpts(int);
	int get_defensepts();
	void set_defensepts(int);
	int get_attackpts();
	void set_attackpts(int);

};